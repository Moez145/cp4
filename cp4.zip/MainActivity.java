package com.example.cp4;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ShareCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        TextView RegisterNow=findViewById(R.id.RegisterNow);
        RegisterNow.setOnClickListener(view -> {
            Intent intent=new Intent(MainActivity.this, MainActivity2.class);
            startActivity(intent);
        });
        EditText Name=findViewById(R.id.UserName);
        EditText Password=findViewById(R.id.TextPassword);
        Button signIn=findViewById(R.id.SignIn);
        signIn.setOnClickListener(view -> {
            String UserName=Name.getText().toString();
            String Pass=Password.getText().toString();
            SharedPreferences sph=getSharedPreferences("Registration",MODE_PRIVATE);
            String valueUserName=sph.getString("Name","");
            String valuePassword=sph.getString("Pass","");
            if(UserName.equals(valueUserName) && Pass.equals(valuePassword)){
                Toast.makeText(MainActivity.this, "Login Sucessfull", Toast.LENGTH_LONG).show();
                Intent intent=new Intent(MainActivity.this,MainActivity3.class);
                startActivity(intent);
            }
        else if((UserName.isEmpty()||Pass.isEmpty())||(!UserName.equals(valueUserName)|| !Pass.equals(valuePassword))){

                Toast.makeText(MainActivity.this, "Incorrect", Toast.LENGTH_LONG).show();
            }

        });
    }
}