package com.example.cp4;

import android.content.IntentSender;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ShareCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.secondPage), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        EditText userName=findViewById(R.id.editText);
        EditText userMail=findViewById(R.id.editText2);
        EditText userPass=findViewById(R.id.editText3);
        String UserName=userName.getText().toString();
        String UserMail=userMail.getText().toString();
        String UserPass=userPass.getText().toString();
        SharedPreferences sp=getSharedPreferences("Registration",MODE_PRIVATE);
        SharedPreferences.Editor editor= sp.edit();
        editor.putString("Name",UserName);
        editor.putString("Mail",UserMail);
        editor.putString("Pass",UserPass);

    }
}